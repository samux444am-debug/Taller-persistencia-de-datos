import { guardarJSON, leerJSON } from "./almacenamiento.js";

const URL_API = "https://jsonplaceholder.typicode.com/users";
const CLAVE_CACHE = "pwc2:directorio:usuarios:v1";
const CLAVE_FAV = "pwc2:directorio:favoritos:v1";
const CLAVE_BUSQUEDA = "pwc2:directorio:busqueda:v1";
const TTL_MS = 10 * 60 * 1000;            // vigencia: 10 minutos

let usuarios = [];
// Favoritos: Set en memoria, arreglo en localStorage
const favoritos = new Set(
  leerJSON("local", CLAVE_FAV, []).filter(Number.isInteger)
);

// Conserva solo id, nombre, correo y empresa
function transformar(lista) {
  return lista.map(u => ({
    id: u.id,
    nombre: u.name,
    correo: u.email,
    empresa: u.company?.name ?? ""
  }));
}

function cacheValida(c) {
  return c !== null && typeof c === "object" &&
    Array.isArray(c.datos) && Number.isFinite(c.guardadoEn);
}

async function obtenerUsuarios() {
  const cache = leerJSON("local", CLAVE_CACHE, null);
  const hayCache = cacheValida(cache);
  const edad = hayCache ? Date.now() - cache.guardadoEn : Infinity;
  const minutos = Math.floor(edad / 60000);

  if (hayCache && edad < TTL_MS) {
    return { datos: cache.datos,
             origen: "Datos desde la cache vigente (hace " +
                     minutos + " min)." };
  }
  try {
    const respuesta = await fetch(URL_API);
    if (!respuesta.ok) throw new Error("HTTP " + respuesta.status);
    const datos = transformar(await respuesta.json());
    guardarJSON("local", CLAVE_CACHE, { guardadoEn: Date.now(), datos });
    return { datos, origen: "Datos recien descargados de la red." };
  } catch {
    if (hayCache) {
      return { datos: cache.datos, aviso: true,
               origen: "Sin conexion: se usa la cache vencida (hace " +
                       minutos + " min)." };
    }
    return { datos: [], aviso: true,
             origen: "Sin conexion y sin datos guardados." };
  }
}

function dibujar() {
  const filtro = document.getElementById("buscador").value
    .trim().toLowerCase();
  const lista = document.getElementById("lista");
  lista.replaceChildren();
  for (const u of usuarios) {
    const texto = (u.nombre + " " + u.correo + " " + u.empresa)
      .toLowerCase();
    if (!texto.includes(filtro)) continue;

    const li = document.createElement("li");
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "fav";
    const esFav = favoritos.has(u.id);
    btn.textContent = esFav ? "\u2605" : "\u2606";
    btn.setAttribute("aria-pressed", String(esFav));
    btn.setAttribute("aria-label", "Favorito: " + u.nombre);
    btn.addEventListener("click", () => {
      if (favoritos.has(u.id)) favoritos.delete(u.id);
      else favoritos.add(u.id);
      guardarJSON("local", CLAVE_FAV, [...favoritos]);   // Set -> arreglo
      dibujar();
    });

    const info = document.createElement("div");
    info.textContent = u.nombre;
    const detalle = document.createElement("small");
    detalle.textContent = u.correo + " \u00b7 " + u.empresa;
    info.appendChild(detalle);

    li.append(btn, info);
    lista.appendChild(li);
  }
}

const buscador = document.getElementById("buscador");
buscador.value = leerJSON("session", CLAVE_BUSQUEDA, "");
buscador.addEventListener("input", () => {
  guardarJSON("session", CLAVE_BUSQUEDA, buscador.value);
  dibujar();
});

const { datos, origen, aviso } = await obtenerUsuarios();
usuarios = datos;
const msg = document.getElementById("origen");
msg.textContent = origen;
msg.className = aviso ? "aviso" : "";
dibujar();
