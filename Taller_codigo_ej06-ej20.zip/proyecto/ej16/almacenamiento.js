// almacenamiento.js - Modulo reutilizable de Web Storage.
// Ninguna funcion lanza excepciones hacia la aplicacion.

// Devuelve el objeto Storage segun el tipo, o null si no es accesible
function obtener(tipo) {
  try {
    if (tipo === "local") return window.localStorage;
    if (tipo === "session") return window.sessionStorage;
  } catch {
    /* acceso bloqueado por el navegador (SecurityError) */
  }
  return null;
}

export function almacenamientoDisponible(tipo) {
  const almacen = obtener(tipo);
  if (!almacen) return false;
  try {
    const prueba = "__prueba__";
    almacen.setItem(prueba, prueba);
    almacen.removeItem(prueba);
    return true;
  } catch {
    return false;
  }
}

// Devuelve true si se guardo, false si fallo
export function guardarJSON(tipo, clave, valor) {
  const almacen = obtener(tipo);
  if (!almacen) return false;
  try {
    almacen.setItem(clave, JSON.stringify(valor));
    return true;
  } catch {
    return false;             // cuota llena, valor circular, etc.
  }
}

// Devuelve el valor leido o "porDefecto" si falta o esta danado
export function leerJSON(tipo, clave, porDefecto = null) {
  const almacen = obtener(tipo);
  if (!almacen) return porDefecto;
  try {
    const texto = almacen.getItem(clave);
    return texto === null ? porDefecto : JSON.parse(texto);
  } catch {
    return porDefecto;        // JSON invalido
  }
}

export function eliminar(tipo, clave) {
  const almacen = obtener(tipo);
  if (!almacen) return false;
  try {
    almacen.removeItem(clave);
    return true;
  } catch {
    return false;
  }
}
