import { almacenamientoDisponible, guardarJSON, leerJSON }
  from "./almacenamiento.js";

const CLAVE = "pwc2:tareas:v1";

function tareaValida(t) {
  return t !== null && typeof t === "object" &&
    Number.isInteger(t.id) && typeof t.texto === "string" &&
    t.texto.trim() !== "" && typeof t.hecha === "boolean";
}

function cargar() {
  const datos = leerJSON("local", CLAVE, []);
  return Array.isArray(datos) ? datos.filter(tareaValida) : [];
}

function guardar() {
  guardarJSON("local", CLAVE, tareas);
}

let tareas = cargar();

function dibujar() {
  const lista = document.getElementById("lista");
  lista.replaceChildren();
  for (const t of tareas) {
    const li = document.createElement("li");
    if (t.hecha) li.className = "hecha";
    const check = document.createElement("input");
    check.type = "checkbox";
    check.checked = t.hecha;
    check.addEventListener("change", () => {
      t.hecha = check.checked;
      guardar();
      dibujar();
    });
    const etiqueta = document.createElement("span");
    etiqueta.textContent = t.texto;
    li.append(check, etiqueta);
    lista.appendChild(li);
  }
  const pendientes = tareas.filter(t => !t.hecha).length;
  document.getElementById("resumen").textContent =
    "Pendientes: " + pendientes + " de " + tareas.length;
}

// Degradacion elegante: la app funciona aunque no se pueda guardar
if (!almacenamientoDisponible("local")) {
  document.getElementById("aviso").textContent =
    "El almacenamiento no esta disponible: los cambios no se conservaran.";
}

document.getElementById("btnLimpiar").addEventListener("click", () => {
  tareas = tareas.filter(t => !t.hecha);
  guardar();
  dibujar();
});

document.getElementById("formulario").addEventListener("submit", (e) => {
  e.preventDefault();
  const campo = document.getElementById("texto");
  const texto = campo.value.trim();
  if (texto === "") return;
  tareas.push({ id: Date.now(), texto, hecha: false });
  guardar();
  dibujar();
  campo.value = "";
});

dibujar();
